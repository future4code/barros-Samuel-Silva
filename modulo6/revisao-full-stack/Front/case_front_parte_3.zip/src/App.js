import Header from "./components/Header";
import Routers from "./routers/Routers";

function App() {
  return (
    <Routers/>
  );
}

export default App;
